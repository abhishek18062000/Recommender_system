To give input to the program write your input in "INPUT.txt" file.
To run the project run following command "python code.py"
The program output will be saved in "OUTPUT.xlsx" file.
"RESULT.py" is sample output.